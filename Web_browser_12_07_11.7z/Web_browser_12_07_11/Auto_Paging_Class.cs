﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Windows.Controls;
using mshtml;
using System.Xml;
using System.IO;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Net;

namespace Web_Browser
{
    public class Auto_Paging_Class
    {
        /* 
         * this is an integer representing the type of method being used for auto paging
         * if the value is 1 then it represents the method in which i seach the next button in every page
         * if the value is 2 then it represents the method in which single variable for page numbering is used
         */
        public int method;   
        
        public HtmlNode node;
        public string variable_name;
        public string path;
        public string base_url;
        public string starting_url;
        public List<string> list_href;
        public string page_no_url;

        public Int16 starting_page_no;
        public Int16 ending_page_no;

        public string next_link_text;   //this will be used for the third method
        public string method3_url;
        public string next_link_tag_name;

        public Auto_Paging_Class()          //constructor for the list of href processed till now
        {
            node = null;
            path = null;
            base_url = null;
            starting_url = null;
            list_href = new List<string>();
            starting_page_no = 0;
            ending_page_no = 0;
        }
    }
}
