﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using mshtml;

namespace Web_Browser
{
    class Node_style
    {
        public IHTMLElement i_ele;
        public string b_color;
        public string b_style;
        public string b_width;
        public Node_style next;
    };
    class List_style
    {
        Node_style head, tail;
        //list constructor initializes headNode_style with 0 and makes it point to the tail marker
        //headNode_style and tailNode_style do not contain any actual elements; tailNode_style always points to itself
        public List_style()
        {
            head = new Node_style(); // List constructor allocates memory for headNode_style and tailNode_style
            head.i_ele = null;
            head.b_color = null;
            head.b_style = null;
            head.b_width = null;

            //and does the initialization
            tail = new Node_style();
            tail.i_ele = null;
            tail.b_color = null;
            tail.b_style = null;
            tail.b_width = null;
            head.next = tail;
            tail.next = tail;
        }

        public void insert_node_begin(IHTMLElement ele)
        {
            Node_style temp = head.next;
            Node_style new_Node_style = new Node_style();

            // saving the element with their style
            new_Node_style.i_ele = ele;
            new_Node_style.b_color = ele.style.borderColor;
            new_Node_style.b_style = ele.style.borderStyle;
            new_Node_style.b_width = ele.style.borderWidth;

            // changing the pointers
            head.next = new_Node_style;
            new_Node_style.next = temp;
        }

        public void purge_list()
        {
            Node_style tmp = head.next;
            while (tmp != tail)
            {
                // restoring the style of the elements before deleting
                tmp.i_ele.style.borderColor = tmp.b_color;
                tmp.i_ele.style.borderStyle = tmp.b_style;
                tmp.i_ele.style.borderWidth = tmp.b_width;

                //iterating to the next element
                tmp = tmp.next;

            }
            //Deleting the list  
            //May be I am not deallocating memory here have to check it
            head.next = tail;
        }

        public void restore_list()
        {
            Node_style tmp = head.next;
            while (tmp != tail)
            {
                // restoring the style of the elements before deleting
                tmp.i_ele.style.borderColor = tmp.b_color;
                tmp.i_ele.style.borderStyle = tmp.b_style;
                tmp.i_ele.style.borderWidth = tmp.b_width;

                //iterating to the next element
                tmp = tmp.next;

            }
        }
        // setting the style
        public void Set_style(string color_name)
        {
            Node_style tmp = head.next;
            while (tmp != tail)
            {
                tmp.i_ele.style.borderColor = color_name;
                tmp.i_ele.style.borderStyle = "solid";
                tmp.i_ele.style.borderWidth = "thin";

                //iterating to the next element
                tmp = tmp.next;

            }
        }


    }

}