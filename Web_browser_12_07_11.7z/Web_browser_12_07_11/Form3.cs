﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Windows.Controls;
using mshtml;
using System.Xml;
using System.IO;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Net;

namespace Web_Browser
{
    public partial class Form3 : Form
    {
        //Item_List l3;
        public Form3()
        {
            //l3 = l1;
            InitializeComponent();

        }
        public void show_data(Item_List l3,Auto_Paging_Class auto_page)
        {
            if (auto_page != null)
            {

                switch (auto_page.method)
                {
                    case 1:
                        // here the functionality of the auto paging will be implemented
                        HtmlWeb htmlWeb = new HtmlWeb();
                        /*                
                        HtmlAgilityPack.HtmlDocument htmlDoc = htmlWeb.Load(auto_page.starting_url);
                        htmlDoc = fix_url_using_agility(htmlDoc,auto_page.base_url);

                        
                        HtmlNode n = htmlDoc.DocumentNode.SelectSingleNode(auto_page.path);
                        if(n!=null)
                        {
                            string url=null;
                            if(n.Attributes!=null)
                            {
                                url=n.Attributes["href"].Value;
                            }
                        */

                        Item_Node temp = l3.Item_head.next;
                        while (temp != null)
                        {
                            temp.l_2.purge_list();
                            temp = temp.next;
                        }




                        string url = auto_page.starting_url;
                        HtmlAgilityPack.HtmlDocument htmldoc = new HtmlAgilityPack.HtmlDocument();
                        do
                        {

                            htmldoc = htmlWeb.Load(url);
                            auto_page.list_href.Add(url);
                            htmldoc = fix_url_using_agility(htmldoc, auto_page.base_url);
                            HtmlNode n = htmldoc.DocumentNode.SelectSingleNode(auto_page.path);
                            if (n != null)
                            {
                                //if (n.InnerText == auto_page.node.InnerText)
                                //{
                                //string url = null;
                                if (n.Attributes != null)
                                {
                                    url = n.Attributes["href"].Value;
                                }
                                else
                                {
                                    url = null;
                                }
                                //}
                            }
                            //htmlDoc = htmlWeb.Load(url);
                            //htmlDoc = fix_url_using_agility(htmlDoc, auto_page.base_url);
                            Item_Node tmp = l3.Item_head.next;
                            while (tmp != null)
                            {
                                //tmp.l_2.purge_list();
                                var links = htmldoc.DocumentNode.SelectNodes(tmp.query);   // running the query to select the elements
                                if (links != null)
                                {
                                    foreach (var link in links)
                                    {
                                        tmp.l_2.insert_node_begin(link);  // inserting the HtmlNodes in the list after the deleting the whole list
                                    }
                                }

                                tmp = tmp.next;
                            }

                            /* 
                             * n=htmlDoc.DocumentNode.SelectSingleNode(auto_page.path);  //searching for the next item in the next page
                              if(n!=null)
                               url=n.Attributes["href"].Value;
                              else
                                url=null;
                             */
                            //}
                        } while ((!auto_page.list_href.Contains(url)) && (url != null));  //url does not exist in the list auto_page.list_href

                        // }
                        break;


                    case 2:
                        //auto paging using the single variable
                        bool flag = false;
                        
                        HtmlWeb htmlWeb1 = new HtmlWeb();
                        HtmlAgilityPack.HtmlDocument htmldoc1 = new HtmlAgilityPack.HtmlDocument();
                        Item_Node temp1 = l3.Item_head.next;   //deleting everything
                        while (temp1 != null)
                        {
                            temp1.l_2.purge_list();
                            temp1 = temp1.next;
                        }

                        string prev_htmlDoc = null;  //for ebay like sites where incrementing the page number shows the last page always

                        int page_no = auto_page.starting_page_no;

                        string temp_url=auto_page.page_no_url;
                        string pattern=auto_page.variable_name+"=\\d*";
                        string replace_string=null;
                        do
                        {

                            replace_string = auto_page.variable_name + "=" + page_no.ToString();
                            temp_url=System.Text.RegularExpressions.Regex.Replace(temp_url, pattern, replace_string);
                            
                            
                            htmldoc1 = htmlWeb1.Load(temp_url);

                            auto_page.list_href.Add(temp_url);
                            htmldoc1 = fix_url_using_agility(htmldoc1, auto_page.base_url);

                            if (!htmldoc1.DocumentNode.InnerText.Equals(prev_htmlDoc))
                            {
                                Item_Node tmp = l3.Item_head.next;
                                flag = false;


                                while (tmp != null)
                                {
                                    //tmp.l_2.purge_list();
                                    var links = htmldoc1.DocumentNode.SelectNodes(tmp.query);   // running the query to select the elements
                                    if (links != null)
                                    {
                                        foreach (var link in links)
                                        {
                                            tmp.l_2.insert_node_begin(link);  // inserting the HtmlNodes in the list after the deleting the whole list
                                        }
                                        flag = flag || true;
                                    }
                                    else
                                    {
                                        flag = flag || false;
                                    }

                                    tmp = tmp.next;
                                }
                                page_no++;
                                prev_htmlDoc = htmldoc1.DocumentNode.InnerText;
                            }
                            else
                            {
                                flag = false;
                            }

                        } while ((flag)&&(page_no<=auto_page.ending_page_no));   //falg=false represents that no matching node was found
                        break;

                    case 3:
                        Item_Node temp3 = l3.Item_head.next;
                        while (temp3 != null)
                        {
                            temp3.l_2.purge_list();
                            temp3 = temp3.next;
                        }

                        string text = auto_page.next_link_text;
                        HtmlWeb web3=new HtmlWeb();
                        HtmlAgilityPack.HtmlDocument doc3=new HtmlAgilityPack.HtmlDocument();
                        doc3.OptionOutputAsXml = true;
                        doc3.OptionFixNestedTags = true;
                        doc3.OptionAutoCloseOnEnd = false;
                        doc3.OptionDefaultStreamEncoding = System.Text.Encoding.Unicode;
                        
                        bool flag2 = false;
                        string method3_url = auto_page.method3_url;
                        do
                        {


                            doc3 = web3.Load(method3_url);
                            doc3 = fix_url_using_agility(doc3, auto_page.base_url);

                            Item_Node tmp3 = l3.Item_head.next;
                            while (tmp3 != null)
                            {
                                //tmp.l_2.purge_list();
                                var links3 = doc3.DocumentNode.SelectNodes(tmp3.query);   // running the query to select the elements
                                if (links3 != null)
                                {
                                    foreach (var link in links3)
                                    {
                                        tmp3.l_2.insert_node_begin(link);  // inserting the HtmlNodes in the list after the deleting the whole list
                                    }
                                }

                                tmp3 = tmp3.next;
                            }
                            auto_page.list_href.Add(method3_url);

                            flag2 = false;
                            HtmlAgilityPack.HtmlNodeCollection c = doc3.DocumentNode.SelectNodes(@"//"+auto_page.next_link_tag_name);
                            if (c != null)
                            {
                                foreach (HtmlNode n in c)
                                {
                                    if (!flag2)
                                    {
                                        if ((n.InnerText.Contains(auto_page.next_link_text)) || (System.Text.RegularExpressions.Regex.Replace(n.InnerText, "&\\w*;", "").Contains(auto_page.next_link_text))) //comparing the innerHtml to find the next tag
                                        {
                                            if (n.Attributes["href"] != null)
                                            {
                                                method3_url = System.Text.RegularExpressions.Regex.Replace(n.Attributes["href"].Value, "amp;", "");
                                                flag2 = true;
                                                //MessageBox.Show("i have got the tag required");
                                                break;
                                            }

                                        }
                                    }
                                    else
                                    {
                                        flag = false;
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                flag = false;
                                break;
                            }


                        } while ((flag2)&&(!auto_page.list_href.Contains(method3_url)));
                        break;
                }

            }
            data_table.DataSource = fill_table(l3);
            this.Show();
        }

        private HtmlAgilityPack.HtmlDocument fix_url_using_agility(HtmlAgilityPack.HtmlDocument ag_htmlDoc,string base_url)
        {
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "href", base_url);
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "src", base_url);
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "background", base_url);
            return ag_htmlDoc;

        }
        private HtmlAgilityPack.HtmlDocument fix_agility_url(HtmlAgilityPack.HtmlDocument ag_htmlDoc, string tag_name, string attribute,string base_url)
        {
            HtmlNodeCollection c4 = ag_htmlDoc.DocumentNode.SelectNodes("//" + tag_name + "[@" + attribute + "]");  // to form a query like this "//a[@href]"
            if (c4 != null)
            {
                foreach (HtmlNode n in c4)
                {
                    HtmlAttribute att = n.Attributes[attribute];
                    if (att.Value.StartsWith(@"/"))
                    {
                        if (base_url.EndsWith(@"/"))
                        {
                            int k = base_url.Length;
                            att.Value = base_url.Remove(k - 1) + att.Value;
                        }
                        else
                        {
                            att.Value = base_url + att.Value;
                        }
                    }
                    else
                    {
                        if (!att.Value.StartsWith("http"))
                        {
                            att.Value = base_url + "/" + att.Value;
                        }
                    }

                }
            }
            return ag_htmlDoc;

        }



        DataTable fill_table(Item_List l)
        {
            DataTable d = new DataTable();

            Item_Node tmp = l.Item_head.next;
            int iteration = 0;
            int max_row_number = 0;
            while (tmp !=null)
            {
                string name = tmp.item_name;
                string type = tmp.item_type;
                string attribute = tmp.item_attribute;
                DataColumn column;

                column = new DataColumn();
                column.ColumnName = name;

                d.Columns.Add(column);

                //Node inner_tmp = tmp.l_2.head.next;
                if (iteration <= 0)   //Just for the first iteration
                {
                    Node inner_tmp = tmp.l_2.head.next;
                    while (inner_tmp != null)
                    {
                        if (attribute == null)          // if the attribute is null i.e the user doesn't want to display the attributes
                        {
                            DataRow drow = d.NewRow();

                            switch (type)
                            {
                                case "text":
                                    drow[name] = inner_tmp.html_node.InnerText;
                                    break;
                                case "Inner Html":
                                    drow[name] = inner_tmp.html_node.InnerHtml;
                                    break;
                                case "Outer Html":
                                    drow[name] = inner_tmp.html_node.OuterHtml;
                                    break;
                            }
                            //Add the row to the datatable.
                            d.Rows.Add(drow);

                        }
                        else // when an attribute has to be added 
                        {
                            //Create a new row
                            DataRow drow = d.NewRow();
                            if (inner_tmp.html_node.Attributes[attribute] != null)
                                drow[name] = inner_tmp.html_node.Attributes[attribute].Value;

                            //Add the row to the datatable.
                            d.Rows.Add(drow);

                            //adding the functionality of downloading the image file

                            if ((tmp.item_tag_name.ToLower() == "img") && (tmp.item_attribute.ToLower() == "src"))
                            {
                                string url = inner_tmp.html_node.Attributes["src"].Value;
                                //downloading the images

                                // Create an instance of WebClient
                                WebClient client = new WebClient();
                                string full_name_file = @"C:\Documents and Settings\prateek.garg\Desktop" + @"\" + url;
                                client.DownloadFileAsync(new Uri(url), full_name_file);    //not able to download the image file
                            }

                        }

                        max_row_number++;
                        inner_tmp = inner_tmp.next;

                    }
                }
                else
                {
                    int row_no = 0;
                    Node inner_tmp = tmp.l_2.head.next;
                    while (inner_tmp != null)
                    {
                        if (row_no < max_row_number)
                        {
                            if (attribute == null)          // if the attribute is null i.e the user doesn't want to display the attributes
                            {
                                switch (type)
                                {
                                    case "text":
                                        d.Rows[row_no][name] = inner_tmp.html_node.InnerText;
                                        break;
                                    case "Inner Html":
                                        d.Rows[row_no][name] = inner_tmp.html_node.InnerHtml;
                                        break;
                                    case "Outer Html":
                                        d.Rows[row_no][name] = inner_tmp.html_node.OuterHtml;
                                        break;
                                }
                            }
                            else // when an attribute has to be added 
                            {

                                if (inner_tmp.html_node.Attributes[attribute] != null)
                                    d.Rows[row_no][name] = inner_tmp.html_node.Attributes[attribute].Value;
                                //adding the functionality of downloading the image file

                                if ((tmp.item_tag_name.ToLower() == "img") && (tmp.item_attribute.ToLower() == "src"))
                                {
                                    string url = inner_tmp.html_node.Attributes["src"].Value;
                                    //downloading the images

                                    // Create an instance of WebClient
                                    WebClient client = new WebClient();
                                    string full_name_file = @"C:\Documents and Settings\prateek.garg\Desktop" + @"\" + url;
                                    client.DownloadFileAsync(new Uri(url), full_name_file);    //not able to download the image file
                                }
                            }
                            row_no++;
                        }
                        else //if the row does not exists
                        {
                            DataRow drow = d.NewRow();
                            if (attribute == null)          // if the attribute is null i.e the user doesn't want to display the attributes
                            {
                                switch (type)
                                {
                                    case "text":
                                        drow[name] = inner_tmp.html_node.InnerText;
                                        break;
                                    case "Inner Html":
                                        drow[name] = inner_tmp.html_node.InnerHtml;
                                        break;
                                    case "Outer Html":
                                        drow[name] = inner_tmp.html_node.OuterHtml;
                                        break;
                                }
                            }
                            else // when an attribute has to be added 
                            {

                                if (inner_tmp.html_node.Attributes[attribute] != null)
                                    drow[name] = inner_tmp.html_node.Attributes[attribute].Value;
                                //adding the functionality of downloading the image file

                                if ((tmp.item_tag_name.ToLower() == "img") && (tmp.item_attribute.ToLower() == "src"))
                                {
                                    string url = inner_tmp.html_node.Attributes["src"].Value;
                                    //downloading the images

                                    // Create an instance of WebClient
                                    WebClient client = new WebClient();
                                    string full_name_file = @"C:\Documents and Settings\prateek.garg\Desktop" + @"\" + url;
                                    client.DownloadFileAsync(new Uri(url), full_name_file);    //not able to download the image file
                                }
                            }
                            d.Rows.Add(drow);
                            max_row_number++;
                            row_no++;

                        }
                        inner_tmp = inner_tmp.next;
                    }
                }
                tmp = tmp.next;
                iteration++;
            }
            return d;

        }



    }
}
