﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using mshtml;
using System.Xml;
using HtmlAgilityPack;

namespace Web_Browser
{
     public class Item_Node
    {
         /* An Html Document in stored with every item becaue
          * as the user changes the selected row in the DataGridView Customised HTML can be shown to it.
          * The customised HTML will be stored in this variable. All the nodes stored in the second list(l_2) 
          * will be the pointers to the doc_ag
          * */
         public HtmlAgilityPack.HtmlDocument doc_ag;
        
         public int id;  // an integer to be associated with every item created by the user
        public HtmlNode x1;
        public string path;
        public string path_without_index;   
        public int no_of_tags;              // value to store the number to tags in the hierarchy that lead to the current element
        public string[] tags_array;
        public int[] indices_array;

        public int second_algo;   //an integer to store the index when the second algo is used

        public string download_path;   //download path for an image type of node
        
         public string original_html;  // to store the original(unaltered) html of the webpage

         // storing the details of the item as selscted by the user in form 2
        public string item_name;
        public string item_type;   // the type of the item which user want to be displayed in the table(like inner HTML, Outer HTML, Text, Attribute)
        public string item_attribute;  //it has a valid value only if the item_type selected by the user is attribute
        public string item_tag_name;  // name of the tag selected by the user. it should be same for the xmlNodes for the entire second list
        public List l_2= new List();

        public string query; // a variable to store the final query required to select all the item. It will be used in autopaging

         public Item_Node next;

         public Item_Node()    // constructor to initialize the variables contained in the class
         {

             doc_ag = new HtmlAgilityPack.HtmlDocument(); //initialising the variable to null
             // May be i need to initialize the options parameter for doc_ag

             tags_array=new string[50];
             indices_array = new int[50];
             item_attribute = null;
             item_type = null;
             path = null;
             id = -1;
             no_of_tags = -1;
             next = null;
             original_html = null;
             query = null;

             second_algo = -1;
         }
    };
    public class Item_List
    {
        //static int item_id = 0; // an integer to assign a Id to the evry item that is being created by the user 

        public Item_Node Item_head;
        //list constructor initializes Item_headnode with 0 and makes it point to the Item_tail marker
        //Item_headnode and Item_tailnode do not contain any actual elements; Item_tailnode always points to itself
        public Item_List()
        {
            Item_head = new Item_Node(); // List constructor allocates memory for Item_headnode and Item_tailnode
            Item_head.x1 = null;
            Item_head.path = null;
            Item_head.path_without_index = null;
            Item_head.doc_ag = null;
            Item_head.query = null;
            

        }


        public void insert_node_begin(HtmlAgilityPack.HtmlDocument doc1, HtmlNode ele, int[] array_indices, string[] array_tags, int index, string p, string p_w_i, string f_item_name, string f_item_type, string f_item_tag_name, string f_item_attribute, int item_id, string html, int algo_no,string dl_path,string q_string)
        {
            Item_Node temp = Item_head.next;
            Item_Node new_node = new Item_Node();

            //new_node.doc_ag = doc1;  //saving the HtmlAgilityPack.HtmlDocument in the item to be inserted

            new_node.x1 = ele;
            new_node.path = p;
            new_node.path_without_index = p_w_i;

            new_node.no_of_tags = index;

            new_node.original_html = html;

            new_node.second_algo = algo_no;  //CHANGE

            new_node.download_path = dl_path;  //setting the download path for image type node
            //new_node.l_2.insert_node_begin(ele,p);  // inserting the HtmlNode in the second list
            
            
            /*
             * copying the elements of the arrays one by one to avoid references.
             * Otherwise simply assigning the awo arrays will make a pointer to it
             * */
            int i;
            for (i = 0; i < index; i++)
            {
                new_node.tags_array[i] = array_tags[i];
                new_node.indices_array[i] = array_indices[i];
            }

                // ASSIGNING THE values returned by form 2
                new_node.item_name = f_item_name;
            new_node.item_type = f_item_type;
            new_node.item_tag_name = f_item_tag_name;
            if (new_node.item_type == "Attribute")
                new_node.item_attribute = f_item_attribute;
            else
                new_node.item_attribute = null;


            //setting the id
            new_node.id=item_id;// assigning a id to the newly created item
            //item_id++;

            new_node.query = q_string;

             new_node.doc_ag.LoadHtml(html); // loading the saved_html passed as argument in thegilitypack.htmlDocument 

            /*
             * inserting a single node in the second list
             */
            var linksThatDoNotOpenInNewWindow = new_node.doc_ag.DocumentNode.SelectNodes(new_node.path); // this should only return one node in the begining
            if (linksThatDoNotOpenInNewWindow != null)
            {
                foreach (var link in linksThatDoNotOpenInNewWindow)
                {
                    if (link.Attributes["style"] == null)
                        link.Attributes.Add("style", "border:3px solid red");
                    else
                        link.Attributes["style"].Value = "border:3px solid red";
                    new_node.l_2.insert_node_begin(link, new_node.path);     // inserting the node in the second list 
                }
            }
            Item_Node prev = Item_head;
            //while (temp != Item_tail)
            while (temp != null)
            {
                // restoring the style of the elements before deleting

                //iterating to the next element
                prev = temp;
                temp = temp.next;

            }           

            // changing the pointers
            //Item_head.next = new_node;
            prev.next = new_node;
            //new_node.next = temp;
            new_node.next = null;
        }

        public void purge_list()
        {
            Item_head.next = null;
        }

        public void restore_list()
        {
            Item_Node tmp = Item_head.next;
            while (tmp != null)
            {
                // restoring the style of the elements before deleting

                //iterating to the next element
                tmp = tmp.next;

            }
        }
        public Item_Node search_item_list_by_id(int selected_id)
        {

            Item_Node tmp = Item_head.next;
            //while ((tmp != Item_tail)&&(tmp!=null))
            while ((tmp != null))
            {
                if (tmp.id == selected_id)
                    break;
                //iterating to the next element
                tmp = tmp.next;

            }
            return tmp;
            
        }

        public void delete_item_by_id(int selected_id)
        {

            Item_Node tmp = Item_head.next;
            Item_Node prev=Item_head;
            //while (tmp != Item_tail)
            while (tmp != null)
            {
                if (tmp.id == selected_id)
                {
                    //tmp.next = tmp.next.next; // changing the pointer so as to delete the item
                    prev.next = tmp.next; // changing the pointer so as to delete the item
                    break;
                }
                //iterating to the next element
                prev = tmp;                
                tmp = tmp.next;

            }

        }

    }

}