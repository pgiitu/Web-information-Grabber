﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using mshtml;
using HtmlAgilityPack;

namespace Web_Browser
{
    public partial class Form2 : Form
    {
        String[] tags;
        int[] relative_index;
        int size;
        string path_with_index;
        IHTMLElement e;
        HtmlNode x;
        List l = new List();
        /*
         * a Boolean flag to indicate whether user has created an item or not. When the user clicks on the 
         * create button then the flag is set to true. This flag is checked in the form1. iF it is true then
         * the item details are inserted in the Item_List.
         */
        public bool item_created_flag;  
        
        public Form2(String[] tags_s, int[] relative_index_s, int size_s, string path_with_index_s, IHTMLElement ele, HtmlNode x1)
        {
            InitializeComponent();
            tags = tags_s;
            relative_index = relative_index_s;
            size = size_s;
            path_with_index = path_with_index_s;
            e = ele;
            x = x1;
            comboBox2.Enabled = false;

            button1.Enabled = false;
            folder_path.Enabled = false;
            
            change_form_for_tag(x1);



          //  item_created_flag = false; // setting the default value of the item_created_flag which will be set to true once th user click the create button to create an item
        //    fill_form();
            item_created_flag = false; // setting the default value of the item_created_flag which will be set to true once th user click the create button to create an item
            fill_form();
        }

        void change_form_for_tag(HtmlNode x1)
        {
            switch (x1.Name.ToLower())
            {
                case "img":
                    //comboBox1.SelectedText = "Attribute";
                    comboBox1.SelectedItem = "Attribute";
                    fill_attributes();
                    comboBox2.SelectedItem = "src";
                    button1.Enabled = true;
                    folder_path.Enabled = true;
                    textBox2.Focus();           // not able to bring cursur in the item name field
                    break;
                case "a":
                    comboBox1.SelectedItem = "Attribute";
                    fill_attributes();
                    comboBox2.SelectedItem = "href";
                    textBox2.SelectionStart = 1;  // not able to bring cursur in the item name field
                    break;
                default:
                    break;
            }
        }




        private void fill_form()
        {
            textBox1.Text = e.tagName.ToLower();
        }

        
        private void fill_attributes()
        {
            
            if ((x.Attributes != null))      // there is some problem in this. Some null reference exception happens.
            {
                if (x.Attributes.Count > 0)
                {
                    comboBox2.Enabled = true;
                    comboBox2.Items.Clear();
                    HtmlAttributeCollection a_col = x.Attributes;
                    foreach (HtmlAttribute at in a_col)
                    {
                        comboBox2.Items.Add(at.Name.ToLower());
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        { 
            if (comboBox1.Text == "Attribute")
            {

                attribute.Enabled = true;
                comboBox2.Enabled = true;
                fill_attributes();
            }
            else
            {
                //attribute.Enabled = false;
                comboBox2.Enabled = false;
            }
        }

        private void create_button_Click(object sender, EventArgs e)
        {
            // inserting the XmlNode element in the second list in the hierarchy
            //actually this the identifying Node for the item

                // verifying the form for empty fields
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Please Enter any name for the Item Name field");
                }
                else
                {
                    if (comboBox1.SelectedItem == null)
                    {
                        MessageBox.Show("Please select any item type");
                    }
                    else
                    {
                        if (comboBox1.SelectedItem.ToString() == "Attribute")
                        {
                            if (comboBox2.SelectedItem == null)
                            {
                                MessageBox.Show("please select any appropriate attribute");
                            }
                            else
                            {
                                l.insert_node_begin(x,path_with_index);  // inserting the clicked node in the begining of the second list in the hierarchy. after this the list should contain only one element as this the first element inserted in the list
                                this.item_created_flag = true; // setting the item created flag as true so that i can insert the item in the item_list in form1
                                this.Visible = false;
                            }
                        }
                        else
                        {
                            l.insert_node_begin(x,path_with_index);  // inserting the clicked node in the begining of the second list in the hierarchy. after this the list should contain only one element as this the first element inserted in the list
                             this.item_created_flag = true; // setting the item created flag as true so that i can insert the item in the item_list in form1
                             this.Visible = false;
                        }

                    }
                }
            
        }


        private void cancel_button_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                folder_path.Text = folderBrowserDialog1.SelectedPath;
            }
        }



    }
}
