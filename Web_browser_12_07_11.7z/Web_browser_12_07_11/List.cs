﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using mshtml;
using System.Xml;
using HtmlAgilityPack;

namespace Web_Browser
{
    public class Node
    {
        //public HtmlAgilityPack.HtmlDocument List_ag_html_doc;
        //public string list_path;
        public HtmlNode html_node;
        public string full_path;
        public Node next;
    }; 
    public class List
    {
        public Node head, tail;
        //list constructor initializes headnode with 0 and makes it point to the tail marker
        //headnode and tailnode do not contain any actual elements; tailnode always points to itself
        public List()
        {
            head = new Node(); // List constructor allocates memory for headnode and tailnode
            head.html_node = null;

            //and does the initialization
            tail = new Node();
            tail.html_node = null;
            head.next = null;
            //tail.next = tail;
        }

        public void insert_node_begin(HtmlNode x1,string f_path)
        {
            Node temp = head.next;
            Node new_node = new Node();
            
            // saving the element with their style
            new_node.html_node = x1;
            new_node.full_path = f_path;
            
            // changing the pointers
            head.next = new_node;
            new_node.next = temp;

            Node prev = head;
            //while (temp != Item_tail)
            while (temp != null)
            {
                prev = temp;
                temp = temp.next;
            }
            prev.next = new_node;
            new_node.next = null;

        }

        public void insert_node_begin(HtmlNode x1) // an overload method to insert a node in the list without the path string
        {
            Node temp = head.next;
            Node new_node = new Node();

            // saving the element with their style
            new_node.html_node = x1;
            new_node.full_path = null;

            Node prev = head;
            //while (temp != Item_tail)
            while (temp != null)
            {
                prev = temp;
                temp = temp.next;
            }

            // changing the pointers
            prev.next = new_node;
            new_node.next = null;
        }

        public void purge_list()
        {
            head.next = null;
        }

        public void restore_list()
        {
            Node tmp = head.next;
            while (tmp != null)
            {

                //iterating to the next element
                tmp = tmp.next;

            }
        }
        // setting the style
        public void Set_style()
        {
            Node tmp = this.head.next;
            while (tmp != tail)
            {
                Console.WriteLine("changing style");
                tmp.html_node.Attributes.Add("style","border:1px solid red");
                //tmp.html_node.Attributes.
                
                //iterating to the next element
                tmp = tmp.next;

            }
        }


    }

}