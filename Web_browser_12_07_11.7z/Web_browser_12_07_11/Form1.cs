﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Windows.Controls;
using mshtml;
using System.Xml;
using System.IO;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Net;
namespace Web_Browser
{
    public partial class Form1 : Form
    {

        DataGridView data_table;

        static int flag = 0;
        static bool document_complete_flag = false;
        string borderColor;
        string borderStyle;
        string borderWidth;
        static int id = 1;      // to give the nuber of items created an id each so as to assign an identifier for each item created


        int second_algo_pos;   // to store the index of the second algo position in the array

        string base_url;

        Sgml.SgmlReader sgmlReader = new Sgml.SgmlReader();
        XmlDocument doc1;

        IHTMLElement e_saved = null;
        Item_Node i_n;                  // a itemnode to store the currently selected item by the user as indicated by the row selected from the grid by the user


        string saved_html;

        string[] tags;
        int[] relative_index;
        int index;
        string path;
        HtmlNode saved;
        Form2 f2;
        public Form3 f3;


        public Auto_Paging_Class auto_page;      //variable for autopaging
        public form_Paging paging_form;
        public string query_string;         // to store the query to be used in auto paging


        public HtmlAgilityPack.HtmlDocument ag_htmlDoc = new HtmlAgilityPack.HtmlDocument();

        bool row_selected;  // to know whether any row of the data grid view is selected or not

        IHTMLElement current_item;
        // LinkedList<IHTMLElement> element_list = new LinkedList<IHTMLElement>();

        List_style l1 = new List_style();  // list to store the list of elemnets clicked by the user
        Item_List i_list = new Item_List();
        // There are various options, to be set as needed

        public Form1()
        {
            row_selected = false;
            InitializeComponent();
            current_item = null;
            relative_index = new int[50];
            tags = new string[50];
            index = 0;
            borderColor = "";
            borderStyle = "";
            borderWidth = "";
            i_n = null;

            query_string = null;


            doc1 = new XmlDocument();

            second_algo_pos = -1;

            // setting the options for Agility pack
            ag_htmlDoc.OptionOutputAsXml = true;
            ag_htmlDoc.OptionFixNestedTags = true;
            ag_htmlDoc.OptionAutoCloseOnEnd = false;
            //ag_htmlDoc.OptionExtractErrorSourceTextMaxLength = 500;

            auto_page = null;       //initialising the variable for autopaging
            add_auto_paging.Visible = false;  //making the add auto paging button invisible
            paging_form = null;


        }

        bool check_mode()
        {
            if (button1.Text.Equals("Turn ON Browser Mode"))
                MessageBox.Show("Please Turn The Brower Mode On By Using The Button On the Upper Right Side Corner to enjoy Surfing");
            else
                return true;
            return false;
        }
        private void Gobutton_Click(object sender, EventArgs e)
        {
            
            
            if (check_mode())
                Navigate(textBox1.Text);
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (check_mode())
                webBrowser1.GoHome();
        }

        private void goBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (check_mode())
                webBrowser1.GoBack();
        }

        private void goForwardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (check_mode())
                webBrowser1.GoForward();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Navigate("http://www.iitrpr.ac.in");
            //Navigate("http://www.google.com");
            //Navigate("http://www.mailgifts2india.com");
            //Navigate("http://www.w3schools.com");
            Navigate("http://shopping.rediff.com/categories/home-decor-&-furnishings/hardware-&-tools");
            //Navigate("http://photography.shop.ebay.com/83857/i.html");
            current_item = null;
            //webBrowser1.DocumentText = "<html><body><p>hello i am prateek</p></body></html>";
        }

        private void load_xhtml()
        {

            ag_htmlDoc.OptionFixNestedTags = true;
            ag_htmlDoc.OptionOutputAsXml = true;
            ag_htmlDoc.OptionWriteEmptyNodes = true;
            ag_htmlDoc.OptionAutoCloseOnEnd = true;

            ag_htmlDoc.LoadHtml(webBrowser1.DocumentText);
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);
            ag_htmlDoc.Save(sw);
            //textBox9.Text = sw.ToString();


            bool temp = webBrowser1.AllowNavigation;
            if (!webBrowser1.AllowNavigation)
                webBrowser1.AllowNavigation = true;
            webBrowser1.DocumentText = sw.ToString();
            webBrowser1.AllowNavigation = temp;

            textBox2.Text = sw.ToString();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (check_mode())
                    Navigate(textBox1.Text);
            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e) // to select the text in the url have to rectify it
        {
            if (flag == 1)
            {
                textBox1.Show();
                flag = 0;
            }
            else
            {
                textBox1.SelectAll();
                flag = 1;
            }
        }

        private void Navigate(String address)
        {
            e_saved = null;
            document_complete_flag = false;
            
            if (String.IsNullOrEmpty(address)) return;
            if (address.Equals("about:blank")) return;
            
            if (!address.StartsWith("file://") && !address.StartsWith("http://") &&
                !address.StartsWith("https://"))
            {
                address = "http://" + address;
            }
            try
            {
                webBrowser1.Navigate(new Uri(address));
                String s1 = webBrowser1.DocumentText;
                textBox2.Text = s1;
                textBox1.Text = address;
            }
            catch (System.UriFormatException)
            {
                return;
            }
            current_item = null; // setting the currently selected IHTMLElement as null
        }


        private void button1_Click(object sender, EventArgs e)
        {
            /* There is some problem in this. Sometimes the page continus to load and the message of loading complete is never displayed
             * So it that case the user is not able to turn off the browsing mode
             * */

            if (button1.Text == "Turn OFF Browser Mode")
            {
                /*
                if (!document_complete_flag)             
                {
                    string s1 = "Please allow the requested page to load.";
                    MessageBox.Show(s1);
                }
                else
                {
                 */
                    webBrowser1.AllowNavigation = false;
                    button1.Text = "Turn ON Browser Mode";
                /*}*/
            }
            else
            {
                webBrowser1.AllowNavigation = true;
                button1.Text = "Turn OFF Browser Mode";
            }

        }
        // to hande the back button in the web browser
        private void backButton_Click(object sender, EventArgs e)
        {
            if (check_mode())
                webBrowser1.GoBack();
        }
        // to handle the forward button in the web browser
        private void forwardButton_Click(object sender, EventArgs e)
        {
            if (check_mode())
                webBrowser1.GoForward();
        }

        // TREE VIEW FUNCTIONS
        struct Nod
        {
            public int pos;
            public string path;
            public string name;
            public HtmlElement ele;
        }
        private void DoStuff(HtmlElementCollection elemColl)
        {
            
            var rootNode = new TreeNode(webBrowser1.Document.Domain)
            {
                Tag = -1
            };
            treeView1.Nodes.Add(rootNode);
            int pos = 0;
            FillDomTree(elemColl, rootNode, pos,"/");
        }

        private static void FillDomTree(HtmlElementCollection currentEle, TreeNode tn, int position, string parentName)
        {

            foreach (HtmlElement element in currentEle)
            {
                TreeNode tempNode;

                var tag = element.TagName;

                if (tag.CompareTo("!") == 0)
                {
                    tempNode = tn.Nodes.Add("<Comment>");
                    Nod n = new Nod();
                    n.pos = position;
                    n.name = element.TagName;
                    n.path = parentName + "/" + element.TagName;
                    parentName = n.path;
                    n.ele = element;
                    tempNode.Tag = n;
                }
                else
                {

                    tempNode = tn.Nodes.Add("<" + element.TagName + ">" + element.InnerText + "<" + element.TagName + "/>");
                    Nod n = new Nod();
                    n.pos = position;
                    n.name = element.TagName;
                    n.path = parentName + "/" + element.TagName;
                    parentName = n.path;
                    n.ele = element;
                    tempNode.Tag = n;
                }

                /** a counter to keep track of the absolute index of the nodes. Stuffing value into tag **/
                //  nodeTracker += 1;
                //tempNode.Tag = nodeTracker;          

                /** over and over and over and over **/
                FillDomTree(element.Children, tempNode, ++position, parentName);

            }
        }
// TREE VIEW FUNCTIONS COMPLETE



        //to perform some computation after the document is copletely loaded
        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

            //use_html_agility_pack();  // calling the function
            
            Uri uri = webBrowser1.Url;
            base_url = uri.GetLeftPart(UriPartial.Authority);  // function to get the base domain of any url that is being displayed in the web browser 

            String s1 = webBrowser1.DocumentText;
            //base_url = webBrowser1.Url.GetLeftPart(UriPartial.Authority);
            textBox2.Text = s1;

            // setting up tree view 
            treeView1.Nodes.Clear();
            HtmlElementCollection elemColl = webBrowser1.Document.GetElementsByTagName("HTML");
            DoStuff(elemColl);
            // setting up of tree view complete


            /* updating the url of the new page but i should do it earlier instead of complete the                  document loading   */
            textBox1.Text = webBrowser1.Url.ToString();
            label2.Text = "Loading Complete";


            /*------------ CODE TO HANDLE THE VENTS---------------------*/
            
                        System.Windows.Forms.HtmlDocument htmlDoc;
                        if (webBrowser1.Document != null)
                        {

                            htmlDoc = webBrowser1.Document;
                            htmlDoc.MouseDown += htmlDoc_MouseDown;
                            htmlDoc.Click += htmlDoc_Click;

                            //htmlDoc.MouseMove += htmlDoc_MouseMove;

                            //htmlDoc.MouseOver += htmlDoc_MouseOver;
                            //htmlDoc.MouseLeave += htmlDoc_MouseLeave;

                        }
             
            /*----------------- CODE OVER --------------*/

            // code to handle the events listeners for the web browser using mshtml library
            mshtml.HTMLDocument doc = (mshtml.HTMLDocument)webBrowser1.Document.DomDocument;

            mshtml.HTMLDocumentEvents2_Event iEvent;
            iEvent = (mshtml.HTMLDocumentEvents2_Event)doc;
            iEvent.onclick += new mshtml.HTMLDocumentEvents2_onclickEventHandler(ClickEventHandler);
            //iEvent.onmouseover += new mshtml.HTMLDocumentEvents2_onmouseoverEventHandler            (MouseOverEventHandler);
            //iEvent.onmouseout += new mshtml.HTMLDocumentEvents2_onmouseoutEventHandler(MouseOutEventHandler);


            //trying sgml reader
            // using SGML to convert HTML to XML
            sgmlReader.DocType = "HTML";
            sgmlReader.WhitespaceHandling = WhitespaceHandling.All;
            sgmlReader.CaseFolding = Sgml.CaseFolding.ToLower;

            //sgmlReader.InputStream = new StringReader(webBrowser1.DocumentText);
            sgmlReader.InputStream = new StreamReader(webBrowser1.DocumentStream);








            // setting the document completed flag true
            document_complete_flag = true;
        }
        /*
        void htmlDoc_MouseOver(object sender, HtmlElementEventArgs e)
        {
        }
         * */
        void htmlDoc_Click(object sender, HtmlElementEventArgs e)
        {
            // trying it out
            /*
            textBox7.Clear();
            string check = webBrowser1.DocumentText;
            Point pt = e.ClientMousePosition;
            HtmlElement tmp = webBrowser1.Document.GetElementFromPoint(pt);
            
            while (tmp != null)
            {
                string test = tmp.TagName;
                textBox7.AppendText(tmp.TagName);
                textBox7.AppendText("-----");
                tmp = tmp.Parent;
            }
            */
            
        }
        void htmlDoc_MouseDown(object sender, HtmlElementEventArgs e)
        {
        }

        /*function to calculate the number of the children with the same tagname as the
         * clicked element*/
        int Number_of_children(HtmlElementCollection col, String s1)
        {
            int count = 0;
            foreach (HtmlElement elem in col)
            {
                if (elem.TagName.ToLower().Equals(s1.ToLower()))
                {
                    count++;
                }
            }
            return count;
        }


        // function to count the number of children in a collection of HTML elements with the given tagname passed as an argument to the function
        int No_of_children(IHTMLElementCollection col, string tag_name, IHTMLElement e)
        {
            int count_children = 0;
            int index = 0;
            bool flag = false;
            foreach (IHTMLElement e1 in col)
            {
                if (e1.tagName.ToLower().Equals(tag_name.ToLower()))
                {
                    count_children++;

                    if ((e1 == e) && (!flag))
                    {
                        flag = true;
                        index = count_children;
                    }
                }
            }
            return (index - 1);
        }

        // function relative index of the IHTMLElement and its tag name passed as an argument
        int cal_relative_index(IHTMLElement e, String tag_name)
        {
            IHTMLElementCollection col = (IHTMLElementCollection)e.parentElement.children;


            //int k = 0;
            int index = 0;
            if (col != null)
            {
                index = No_of_children(col, tag_name, e);
            }
            return index;
        }

        /* function with the array of tags and relative indices as arguments and 
         * computes the complete path of the selected element*/
        string compute_path_string(String[] S, int[] A, int size)
        {
            int i = 0;
            string path = @"/html[1]/";
            for (i = size - 1; i >= 0; i--)
            {
                if (!S[i].ToLower().Equals("tbody"))        // ignoring the tbody tag
                {
                    if (i == 0)
                    {
                        //path = path + S[i].ToLower();// + "[" + A[i].ToString() + "]";
                        path = path + S[i].ToLower() + "[" + A[i].ToString() + "]";
                        //path = path + @"webBrowser1";
                    }
                    else
                    {
                        path = path + S[i].ToLower() + "[" + A[i].ToString() + @"]/";
                    }
                }
            }
            return path;
        }

        /* function to compute path without the relative indices of the elements*/

        string compute_path_without_index(String[] S, int size)
        {
            int i = 0;
            string path = @"/html/";
            for (i = size - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    path = path + S[i].ToLower();
                }
                else
                {
                    path = path + S[i].ToLower() + @"/";
                }
            }
            return path;
        }


        /* function to set the border of the element being clicked*/
        void draw_border(IHTMLElement ele, string color_name)
        {
            ele.style.borderColor = color_name;
            ele.style.borderStyle = "solid";
            ele.style.borderWidth = "thin";
        }

        /* function to capture the click by the user*/
        private bool ClickEventHandler(mshtml.IHTMLEventObj e)
        {

            if (!webBrowser1.AllowNavigation)       // check that the navigation mode is off
            {


                //inserting to list
                l1.insert_node_begin(e.srcElement);



                current_item = e.srcElement;
                
                
                /*  if any row is selected of the grid view then enable the add to item butoon
                 * but i have not yet handled the case when the row-selected value is set to false. 
                 * it has to be done when no row of the data grid is selected
                 */
                if (row_selected)
                    add_item.Enabled = true;


                textBox3.Text = e.srcElement.outerHTML;
                textBox4.Text = e.srcElement.innerHTML;
                textBox_sgml.Text = e.srcElement.innerText;


                //restoring the style of the previously saved element
                if (e_saved != null)
                {
                    e_saved.style.borderColor = borderColor;
                    e_saved.style.borderStyle = borderStyle;
                    e_saved.style.borderWidth = borderWidth;
                }

                // saving the style of the currently clicked element
                e_saved = e.srcElement;

                borderColor = e.srcElement.style.borderColor;
                borderStyle = e.srcElement.style.borderStyle;
                borderWidth = e.srcElement.style.borderWidth;

                //changing the style of the current element that is clicked
                draw_border(e.srcElement, "red");



                int i;
                index = 0;
                IHTMLElement temp = e.srcElement;
                textBox5.Text = e.srcElement.tagName;
                textBox_path.Clear();
                //while (temp != null)
                while (!(temp.tagName.ToLower().Equals("html"))) // I donot know why the loop is running indefinitely when we are using null condition.
                //while (!(temp.tagName.ToLower().Equals("body") ))
                {
                    i = cal_relative_index(temp, temp.tagName);
                    //textBox_path.AppendText("----");
                    tags[index] = temp.tagName;
                    relative_index[index] = i + 1;  // to take care that in xpath the indices start from 1 as opposer to here where it starts from 0
                    index++;
                    //textBox_path.AppendText(temp.tagName);
                    //textBox_path.AppendText("-");
                    //textBox_path.AppendText(i.ToString());
                    //textBox_path.AppendText("----");
                    temp = temp.parentElement;
                }
                if (temp == null)
                    textBox_path.Text = "i donot know why is this is not getting executed";

                path = compute_path_string(tags, relative_index, index);
                textBox_path.Text = path;
                //textBox5.Text = path;
                String path_no_index = compute_path_without_index(tags, index);



            }
            else
            {
                //webBrowser1.start
            }
            return true;

        }


        /* capturing the evenet in which new window is being opened and then disallowing the opening of the new window*/
        private void webBrowser1_NewWindow(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
        }

        void Set_style(LinkedList<IHTMLElement> list)
        {
            foreach (IHTMLElement ele5 in list)
            {
                draw_border(ele5, "blue");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Set_style(element_list);
            l1.Set_style("blue");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            l1.purge_list();
        }

        /* earlier this function was created using sgmlerader's doc1 but now i am using htmlAgility Pack ag_htmlDoc*/
        private void button4_Click(object sender, EventArgs e)
        {
            //Application.Run(new Form2();
            if (current_item != null)
            {

                textBox_sgml.Text = ag_htmlDoc.DocumentNode.OuterHtml;
                //textBox11.Text = ag_htmlDoc.DocumentNode.OuterHtml;

                
                /*
                * may be i need to change here a bit so as to ensure tha onlt one node is selected
                * */
                //CHANGE
                saved = ag_htmlDoc.DocumentNode.SelectSingleNode(path); // only one node is needed
                
                
                //webBrowser1.Document.Write(doc1.OuterXml);
                if (saved != null)  // this is very important. It should not be null.
                {
                    /*
                     * ther is some problem here with a P tag. The inner text is set to "" when seen through debugger
                     * */
                    /*
                    saved.InnerText = current_item.innerText;
                    saved.InnerHtml = current_item.innerHTML;
                    saved.OuterHtml = current_item.outerHTML;
                    */
                    query_string = path;

                    second_algo_pos = index-1; //CHANGE
                    f2 = new Form2(tags, relative_index, index, path, current_item, saved);
                    f2.Show();
                    f2.VisibleChanged += new System.EventHandler(this.Form2_VisibleChanged);
                }
                else    //if the full path is not enough to find out the element
                {
                    // need to implement another algorithm in case if the item matched can not be found
                    int pos = compute_index_second_algo_for_single_result(tags, relative_index, index);    //CHANGE
                    if (pos != -1)
                    {
                        second_algo_pos = pos;

                        
                        string temp_path = compute_second_algo(pos,relative_index,tags);
                        query_string = temp_path;
                        saved = ag_htmlDoc.DocumentNode.SelectSingleNode(temp_path);  // it has to return a single element other wise null reference error will occur
                        //saved.InnerText = current_item.innerText;
                        //saved.InnerHtml = current_item.innerHTML;
                        //saved.OuterHtml = current_item.outerHTML;
                        

                        f2 = new Form2(tags, relative_index, index, path, current_item, saved);
                        f2.Show();
                        f2.VisibleChanged += new System.EventHandler(this.Form2_VisibleChanged);
                    }
                    else
                    {

                        MessageBox.Show("Your request to create this item cannot be completed due to some problem internally");
                    }
                }
            }

        }

        /*
         * function to compute the query for the second algorithm
         * */
        string compute_second_algo(int size, int[] A, string[] S)
        {
            int i = 0;
            string path = @"//";
            for (i = size - 1; i >= 0; i--)
            {
                if (!S[i].ToLower().Equals("tbody"))        // ignoring the tbody tag
                {
                    if (i == 0)
                    {
                        //path = path + S[i].ToLower();// + "[" + A[i].ToString() + "]";
                        path = path + S[i].ToLower() + "[" + A[i].ToString() + "]";
                        //path = path + @"\";
                    }
                    else
                    {
                        path = path + S[i].ToLower() + "[" + A[i].ToString() + @"]/";
                    }
                }
            }
            return path;

        }


        /*
         * function to compute the relative Xpath Query that is able to select a single element*/
        private int compute_index_second_algo_for_single_result(string[] S, int[] A, int size)  //CHANGE
        {
            int pos = size - 1;
            int i = 0;
            int count = -1;
            while ((count != 1) && (pos != 0))
            {
                string path = @"//";    // starting with the body tag  donot need a html tag
                for (i = pos; i >= 0; i--)
                {
                    //if ((!(S[i].ToLower().Equals("tbody"))) && (!(S[i].ToLower().Equals("form"))))        // ignoring the tbody tag
                    if ((!(S[i].ToLower().Equals("tbody"))))        // ignoring the tbody tag
                    {
                        if (i == 0)
                        {
                            //path = path + S[i].ToLower();// + "[" + A[i].ToString() + "]";
                            path = path + S[i].ToLower() + "[" + A[i].ToString() + "]";
                            //path = path + @"\";
                        }
                        else
                        {
                            path = path + S[i].ToLower() + "[" + A[i].ToString() + @"]/";
                        }
                    }
                }
                HtmlNodeCollection l1 = ag_htmlDoc.DocumentNode.SelectNodes(path);
                if (l1 != null)
                {
                    if (l1.Count == 1)
                    {
                        count = 1;
                    }
                }
                pos--;
            }
            if (count == 1)
            {
                return (pos+1);   // the case when we find a index which gives only one result
            }
            else
            {
                return -1;   // there is some internal error in this case
            }
        }


        private void Form2_VisibleChanged(object sender, EventArgs e)
        {
            if (f2.item_created_flag)
            {
                Console.WriteLine("data grid view 1");
                /*
                * insertin the item in the list
                * here 
                * textBox1.text= tag name
                * textBox2.text=item name
                * comboBox1.selectedText=item type
                * comboBox2.selectedText=attribute name if it is there
                * id= We have associated a ID with every item being created by the
                 * f2.folder_path.text= represents the path of the folder in which an image file is to be downloaded
                * user so as to search the outer list of items
                 * 
                */

                if (f2.comboBox2.SelectedItem != null)
                {
                    i_list.insert_node_begin(ag_htmlDoc, saved, relative_index, tags, index, path, path, f2.textBox2.Text, f2.comboBox1.SelectedItem.ToString(), f2.textBox1.Text, f2.comboBox2.SelectedItem.ToString(), id, saved_html, second_algo_pos,f2.folder_path.Text,query_string);
                    dataGridView1.Rows.Add(id, f2.textBox2.Text, f2.comboBox1.SelectedItem.ToString(), f2.textBox1.Text, f2.comboBox2.SelectedItem.ToString(),"1");  //adiing the dow in the data grid view "1" represents the number of items column
                    int counter;
                    for (counter = 0; counter < (dataGridView1.Rows.Count); counter++)
                    {
                        if (dataGridView1.Rows[counter].Cells[0].Value != null)
                        {
                            if (((int)dataGridView1.Rows[counter].Cells[0].Value) == id)
                            {
                                dataGridView1.Rows[counter].Selected = true;
                                i_n = i_list.search_item_list_by_id(id);  // serching for the item node with the selected id
                                break;
                            }
                        }
                    }
                    //dataGridView1.Rows[((int)dataGridView1.Rows[index1].Cells[0].Value)==id].Selected = true;               
                }
                else                                // when the attribute field is empty                
                {
                    
                    //CHANGE
                    i_list.insert_node_begin(ag_htmlDoc, saved, relative_index, tags, index, path, path, f2.textBox2.Text, f2.comboBox1.SelectedItem.ToString(), f2.textBox1.Text, null, id, saved_html, second_algo_pos,f2.folder_path.Text,query_string);
                    dataGridView1.Rows.Add(id, f2.textBox2.Text, f2.comboBox1.SelectedItem.ToString(), f2.textBox1.Text,"","1");
                    int counter;
                    for (counter = 0; counter < (dataGridView1.Rows.Count); counter++)
                    {
                        if (dataGridView1.Rows[counter].Cells[0].Value != null)
                        {
                            if (((int)dataGridView1.Rows[counter].Cells[0].Value) == id)
                            {
                                dataGridView1.Rows[counter].Selected = true;
                                i_n = i_list.search_item_list_by_id(id);  // serching for the item node with the selected id
                                break;
                            }
                        }
                    }
                }
                //dataGridView1.Columns[0].Visible = false;
                id++;  // incrementing the id for the next element               
            }
            else
            {
                dataGridView1.Rows.Add("1", "hello", "it is prateek", "how are you", "chandhok");
                Console.WriteLine("hello the value is false");
            }

        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            label2.Text = "Please wait while the Web Page is Loading";
        }
        /*
        private void button5_Click(object sender, EventArgs e)
        {

            textBox5.AppendText(path);
        }
        */
        /*
         * calling the function which will use the html agility pack
         * */
        private void use_html_agility_pack()
        {

            HtmlWeb htmlWeb = new HtmlWeb();

            // Creates an HtmlDocument object from an URL

            ag_htmlDoc = htmlWeb.Load(webBrowser1.Url.ToString());
            textBox6.Text = fix_url_using_agility(ag_htmlDoc).DocumentNode.OuterHtml;
            webBrowser1.Document.Write(textBox6.Text);

            saved_html = textBox6.Text; // saving the Html_source which has been corrected for url's

        }


        private void button5_Click_1(object sender, EventArgs e)
        {
            
            HtmlWeb htmlWeb = new HtmlWeb();

            //webBrowser1.Document.Write(webBrowser1.DocumentText);
            //webBrowser1.Document.
            //webBrowser1.Document.Write(webBrowser1.DocumentStream.ToString());

            //ag_htmlDoc.LoadHtml(webBrowser1.DocumentText);
            //webBrowser1.Document.Write(fix_url_using_agility(ag_htmlDoc).DocumentNode.OuterHtml);
            //return;
            
            
            ag_htmlDoc = htmlWeb.Load(webBrowser1.Url.ToString());
            
            
            textBox6.Text = fix_url_using_agility(ag_htmlDoc).DocumentNode.OuterHtml;
            webBrowser1.Document.Write(textBox6.Text);
            saved_html = textBox6.Text; // saving the Html_source which has been corrected for url's


            listBox1.Items.Clear();
            listBox2.Items.Clear();

            HtmlNodeCollection meta_tags = ag_htmlDoc.DocumentNode.SelectNodes("//meta[@name]");  //getting a collection of all the meta tags
            if (meta_tags != null)
            {
                foreach (HtmlNode n in meta_tags)
                {
                    listBox1.Items.Add(n.Attributes["name"].Value);
                }
            }
            //using sgmlreader
            /*
            doc1.Load(sgmlReader);
            doc1=fix_url_using_sgml(doc1);
            webBrowser1.Document.Write(doc1.DocumentElement.OuterXml);
            //Stream outStream=new StreamReader(;
            //doc1.Save(outStream);
            ag_htmlDoc.LoadHtml(doc1.OuterXml);
            saved_html = doc1.OuterXml;
            //textBox6.Text = doc1.DocumentElement.OuterXml;
            textBox6.Text = doc1.OuterXml;
            //webBrowser1.Document.Write(ag_htmlDoc.DocumentNode.OuterHtml);
            */

        }

        XmlDocument fix_url_using_sgml(XmlDocument xdoc)
        {
            xdoc=fix_sgml_url(xdoc,"*","href");
            xdoc = fix_sgml_url(xdoc, "*", "src");
            xdoc = fix_sgml_url(xdoc, "*", "background");
            return xdoc;
        }

        XmlDocument fix_sgml_url(XmlDocument xdoc, string tag_name, string attribute)
        {
            XmlNodeList c4 = xdoc.SelectNodes("//" + tag_name + "[@" + attribute + "]");  // to form a query like this "//a[@href]"
            if (c4 != null)
            {
                foreach (XmlNode n in c4)
                {
                    XmlAttribute att = n.Attributes[attribute];
                    if (att.Value.StartsWith(@"/"))
                    {
                        if (base_url.EndsWith(@"/"))
                        {
                            int k = base_url.Length;
                            att.Value = base_url.Remove(k - 1) + att.Value;
                        }
                        else
                        {
                            att.Value = base_url + att.Value;
                        }
                    }
                    else
                    {
                        if (!att.Value.StartsWith("http"))
                        {
                            att.Value = base_url + "/" + att.Value;
                        }
                    }

                }
            }
            return xdoc;

        }

        


        /* function to fix the url when passed a HTmlAgilityPack.HtmlDocument
         * a tagname and a attribute name(attribute which can contain a URL) 
         * The function return the HtmlAgilityPack.HtmlDocument
         */
        private HtmlAgilityPack.HtmlDocument fix_agility_url(HtmlAgilityPack.HtmlDocument ag_htmlDoc, string tag_name, string attribute)
        {
            HtmlNodeCollection c4 = ag_htmlDoc.DocumentNode.SelectNodes("//" + tag_name + "[@" + attribute + "]");  // to form a query like this "//a[@href]"
            if (c4 != null)
            {
                foreach (HtmlNode n in c4)
                {
                    HtmlAttribute att = n.Attributes[attribute];
                    if (att.Value.StartsWith(@"/"))
                    {
                        if (base_url.EndsWith(@"/"))
                        {
                            int k = base_url.Length;
                            att.Value = base_url.Remove(k - 1) + att.Value;
                        }
                        else
                        {
                            att.Value = base_url + att.Value;
                        }
                    }
                    else
                    {
                        if (!att.Value.StartsWith("http"))
                        {
                            att.Value = base_url + "/" + att.Value;
                        }
                    }

                }
            }
            return ag_htmlDoc;

        }

        private HtmlAgilityPack.HtmlDocument fix_url_using_agility(HtmlAgilityPack.HtmlDocument ag_htmlDoc)
        {
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "href");
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "src");
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "*", "background");

            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "a", "href");
            /*            HtmlNodeCollection c4 = ag_htmlDoc.DocumentNode.SelectNodes("//a[@href]");
                        if (c4 != null)
                        {
                            foreach (HtmlNode n in c4)
                            {
                                HtmlAttribute att = n.Attributes["href"];
                                if (att.Value.StartsWith(@"/"))
                                {
                                    if (webBrowser1.Url.ToString().EndsWith(@"/"))
                                    {
                                        int k = webBrowser1.Url.ToString().Length;
                                        att.Value = webBrowser1.Url.ToString().Remove(k - 1) + att.Value;
                                    }
                                    else
                                    {
                                        att.Value = webBrowser1.Url.ToString() + att.Value;
                                    }
                                }
                            }
                        }
             */
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "link", "href");
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "img", "src");
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "script", "src");
            ag_htmlDoc = fix_agility_url(ag_htmlDoc, "input", "src");
            return ag_htmlDoc;

        }

        // function to take care of the event when the user selects any row of the grid*/ 
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int index1 = e.RowIndex;
            if(dataGridView1.Rows[index1].Cells[0].Value!=null)
            {
                int selected_id = (int)dataGridView1.Rows[index1].Cells[0].Value;  // have to compare integer
            
                row_selected = true;
                if (current_item != null)       // enable the add to item button only if any row is selected and any item is selcted
                    add_item.Enabled = true;

                i_n = i_list.search_item_list_by_id(selected_id);  // serching for the item node with the selected id

                //int id = dataGridView1;
                if ((i_n != null))
                {
                    if ((i_n.doc_ag != null))
                    {
                        string htmlResult = i_n.doc_ag.DocumentNode.WriteTo(); // there is some error while deleting an item
                        
                        //webBrowser1.AllowNavigation = true;
                        //webBrowser1.DocumentText = null;
                        //webBrowser1.Document.Write(i_n.doc_ag.DocumentNode.OuterHtml);
                        /*
                        //webBrowser1.DocumentText = htmlResult;  // I don't know why it is not happening. the webBrowser1.documenttext's lenght is increasing in lenght and multiple copies are being created
                        webBrowser1.Navigate("about:blank");       // i don't know why it isn't working. The document text is not getting changed
                        webBrowser1.Document.Write(String.Empty);
                        webBrowser1.DocumentText = htmlResult;
                        */
                        //webBrowser1.AllowNavigation = false;
                        //textBox_sgml.Text = htmlResult;
                        //webBrowser1.AllowNavigation = true;
                        //webBrowser1.Document.Write(i_n.doc_ag.DocumentNode.WriteTo());
                        //webBrowser1.Document.OpenNew(true);
                        //webBrowser1.Navigate("about:blank");       // i don't know why it isn't working. The document text is not getting changed
                        //webBrowser1.Document.Write(String.Empty);
                        //webBrowser1.DocumentText = htmlResult;
                        //webBrowser1.DocumentText = htmlResult;
                        //webBrowser1.AllowNavigation = false;
                    }
                }
            }
        }


        private void button6_Click(object sender, EventArgs e)
        {
            HtmlAgilityPack.HtmlDocument ag_htmlDoc_copy = new HtmlAgilityPack.HtmlDocument();
            ag_htmlDoc_copy=ag_htmlDoc;

            //var links = ag_htmlDoc_copy.DocumentNode.SelectNodes("//div[1]/div[1]/div[1]/ul[1]/li[5]/a[1]");
            //var links = ag_htmlDoc_copy.DocumentNode.SelectNodes("/html[1]/body[1]/table[1]/form[1]/tbody[1]/tr[3]/td[2]/table[1]/tbody[1]/tr[1]/td[2]/table[1]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[2]/td[2]/table[1]/tbody[1]/tr[2]/td[1]/table[1]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[1]/td[1]/a[1]/img[1]");
            //var links = ag_htmlDoc_copy.DocumentNode.SelectNodes("//html[1]/body[1]/table[1]/form[1]/tr[3]/td[2]/table[1]/tr[1]/td[2]/table[1]/tr[1]/td[2]/table[1]/tr[2]/td[2]/table[1]/tr[2]/td[1]/table[1]/tr[1]/td[1]/table[1]/tr[1]/td[1]/a[1]/img[1]");
            var links = ag_htmlDoc_copy.DocumentNode.SelectNodes("/html[1]/body[1]/center[1]/table[1]/tr[1]/td[1]/a");
            //var links = ag_htmlDoc_copy.DocumentNode.SelectNodes("//tr[1]/td[1]/a[1]/img[1]");
            if (links != null)
            {
                foreach (var link in links)
                    if (link.Attributes["style"] == null)
                        link.Attributes.Add("style", "border:3px solid red");
                    else
                        link.Attributes["style"].Value = "border:3px solid red";
            }
            else
            {
                MessageBox.Show("returned null");
            }

                string htmlResult = ag_htmlDoc_copy.DocumentNode.WriteTo();

            webBrowser1.DocumentText = htmlResult;   // this change is working only when the navigation is allowed in the webbrowser
                textBox_sgml.Text = ag_htmlDoc_copy.DocumentNode.OuterHtml;
            //Console.WriteLine(ag_htmlDoc.DocumentNode.OuterHtml);
        }

        /*
         * this fuction will iterate through the the two arrays and 
         * compute the xpath quesy string. In the indices array an index of 0 indicates '*'
         * while forming the query
         * */
        
        string compute_xpath_string_query(int change, int[] indices_array, string[] tags_array,int size,int second_algo_pos)
        {
            if(change>=0)
                indices_array[change] = 0; // indicating '*' in the xpath string in this array
            
            int i = 0;
            string xpath = @"//";
//            for (i = size - 1; i >= 0; i--)
            for (i = second_algo_pos - 1; i >= 0; i--)
            {
                if (!(tags_array[i].ToLower().Equals("tbody")))
                {
                    if (i == 0)
                    {
                        if (indices_array[i] == 0)
                        {
                            //xpath = xpath + tags_array[i].ToLower() + "[" + "*" + "]";
                            xpath = xpath + tags_array[i].ToLower();// +"[" + "*" + "]";
                        }
                        else
                        {
                            //path = path + S[i].ToLower();// + "[" + A[i].ToString() + "]";
                            xpath = xpath + tags_array[i].ToLower() + "[" + indices_array[i].ToString() + "]";
                            //path = path + @"\";
                        }
                    }
                    //4 IP EXTENSION FALT NO DHRUVA APARATMENT 225 DELHI-92
                    else
                    {
                        if (indices_array[i] == 0)
                        {
                            //xpath = xpath + tags_array[i].ToLower() + "[" + "*" + @"]/";
                            xpath = xpath + tags_array[i].ToLower() + @"/";// "[" + "*" + @"]/";
                        }
                        else
                        {
                            xpath = xpath + tags_array[i].ToLower() + "[" + indices_array[i].ToString() + @"]/";
                        }
                    }
                }
            }
            return xpath;

        }

        /*
         * function to add a item to a particular item already created by the user
         */
        private void add_item_Click(object sender, EventArgs e)
        {
            /*  Also i have to change the value of i_n to null when the gridview is deselected by the user.
             * I haven't handled that event yet. So need to do it in the future.
             * 
             */
            if (i_n != null)                // checking if any row in the grid is selected or not
            {
                /* now I have to put some conditions so as to verify 
                 * whether the new item selected by the user is compatible to the already selected item 
                 * in the gridview.
                 */
                if ((current_item.tagName.ToLower().Equals(i_n.item_tag_name.ToLower())) && (index == i_n.no_of_tags)) // checking the tag name and the the index
                {
                    if (compare_two_arrays(i_n.tags_array, tags, index))     // the array of tags has to be exactky same
                    {
                        /*
                         * there has to be change ony in one of the relative indices
                         * of the two items selected by the user
                         */
                        int change = check_for_change_in_relative_indices(relative_index, i_n.indices_array, index);
                        if (change != -1)
                        {
                            /*
                             * Now we have got that the two items are valid. So now i need to write the algorithm 
                             * so as to select the same type of elements
                             */
                            string query = compute_xpath_string_query(change, i_n.indices_array, i_n.tags_array, index,second_algo_pos+1);

                            /*
                             * will have to see the below commented two lines. 
                             * I think i do not need it
                             * */
                            //string original = i_n.original_html;  // saving the original Html in a new string
                            //i_n.doc_ag.LoadHtml(original); // loading the saved_html passed as argument in thegilitypack.htmlDocument
                            
                            var links = i_n.doc_ag.DocumentNode.SelectNodes(query);
                            
                            if (links != null)
                            {
                              
                                i_n.l_2.purge_list();  // deleting the whole Second list
                                foreach (var link in links)
                                {
                                    /*
                                     * insert the style attribute
                                     * */
                                    //link.Attributes.Add("style", "border:3px solid red");
                                    if (link.Attributes["style"] == null)
                                        link.Attributes.Add("style", "border:3px solid red");
                                    else
                                        link.Attributes["style"].Value = "border:3px solid red";// "border:3px solid red";

                                    i_n.l_2.insert_node_begin(link);  // re-inserting the HtmlNodes in the list after the deleting the whole list
                                }
                                i_n.query = query;
//removed the message            //MessageBox.Show("The item u have selected can be processed. the path string is:-  " + query + "   and the number of elements returned are:- " + links.Count.ToString());
                                
                                
/*                                
                                if ((i_n.item_tag_name.ToLower() == "img")&&(i_n.item_attribute.ToLower()=="src"))
                                {
                                    //i_n.download_path
                                    Node inner_tmp = i_n.l_2.head.next;
                                    while (inner_tmp != null)
                                    {

                                        string url = inner_tmp.html_node.Attributes["src"].Value;
                                        //downloading the images

                                         // Create an instance of WebClient
                                           WebClient client = new WebClient();
                                              // Hookup DownloadFileCompleted Event
                                       //client.DownloadFileCompleted +=
                                         //                  new AsyncCompletedEventHandler(client_DownloadFileCompleted);
                                        // Start the download and copy the file to c:\temp
                                       string full_name_file=i_n.download_path+@"\"+url;
                                        client.DownloadFileAsync(new Uri(url),full_name_file);    //not able to download the image file
                                       inner_tmp = inner_tmp.next;
                                    }
                                }
*/
                                /* code to update the number of items in the grid view*/
                                DataGridViewRowCollection col =dataGridView1.Rows;
                                foreach(DataGridViewRow r in col)
                                {
                                    if(r.Cells[0].Value.ToString()==i_n.id.ToString())
                                    {
                                        r.Cells[5].Value=links.Count.ToString();  //updating the number of items
                                        break;
                                    }
                                }
                                //dataGridView1.Rows.GetFirstRow(dataGridView1[0].value.toString() == i_n.id.ToString());
                                /*
                                string s1 = i_n.doc_ag.DocumentNode.OuterHtml;
                                FileStream fs = File.Open("c:\\test.html",FileMode.Create);
                                StreamWriter sw = new StreamWriter(fs);
                                sw.Write(s1);
                                sw.Flush();
                                sw.Close();
                                
                                webBrowser1.DocumentText  = null;
                                
                                webBrowser1.Navigate("file://c:/test.html", true);
                                webBrowser1.Navigate("file://c:/test.html", true);
                                webBrowser1.Navigate("file://c:/test.html", true);
                                
                                
                                webBrowser1.Document.Write(s1);

                                webBrowser1.Show();
                                webBrowser1.Update();
                                webBrowser1.Refresh();
                                webBrowser1.Refresh();
                                webBrowser1.Refresh();
                                
                                webBrowser1.Refresh(WebBrowserRefreshOption.Completely);
                                webBrowser1.Refresh(WebBrowserRefreshOption.Completely);
                                webBrowser1.Refresh(WebBrowserRefreshOption.Completely);
                                //webBrowser1.Navigate("file://c:/test.html");
                                //webBrowser1.Document.Write(i_n.doc_ag.DocumentNode.OuterHtml);
                                //webBrowser1.Document.
                                 * 
                                 * */
                            }
                            else
                            {
                                MessageBox.Show("The item u have selected can be processed. the path string is:-  " + query + "   ----Sorry no item could be found matching your request");
                            }
                            /*
                             * this fuction will iterate through the the two arrays and 
                             * compute the xpath quesy string. In the indices array an index of 0 indicates '*'
                             * while forming the query
                             * */
                        }
                        else
                        {
                            MessageBox.Show("The item selected by you is not compatible. So please select the appropriate item.3");
                        }
                    }
                    else
                    {
                        MessageBox.Show("The item selected by you is not compatible. So please select the appropriate item.4");
                    }
                }
                else
                {
                    MessageBox.Show("The item selected by you is not compatible. So please select the appropriate item. 5");
                }
 
            }

        }
        /*
         * this function returns the index of change if there is only one change in the two arrays
         * otherwise it returns -1 indicating that the two items are not compatible
         */ 
        private int check_for_change_in_relative_indices(int[] a,int[] b,int size)
        {
            int change, i,index;
            change = 0;
            index = -2;  // index -2 represents that there should not be any change in the query string.
            //int tmp=0;
           
            for (i = 0; i < size; i++)
            {
                if (b[i] != 0)          // value 0 represents '*' so we need to check for it. we need not compare those indices array
                {
                    if (a[i] != b[i])           // if there is any change in the indices then increment the number of change
                    {
                        change++;
                        index = i;
                    }
                }
                
            }
            if ((change <= 1))            // this means that there is only one change so we can return the index of change
            {
                return index;
            }
            else
            {
                return -1;
            }
        }

        /*
         * this function is used to compare
         * the two tags_arry that all the tages should be same. only the 
         * relative indices can differ
         * */
        private bool compare_two_arrays(string[] a, string[] b, int size)  // this is only called when the length of the arrays are equal
        {
            int i;
            for(i=0;i<size;i++)
            {
                if(!a[i].ToLower().Equals(b[i].ToLower()))
                {
                    return false;
                }
            }
            return true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            f3 = new Form3();
            //f3.Show(); 
            f3.show_data(i_list, auto_page);  //passing the list and the autopage parameter. The work of autopaging will be done there only
            //data_table = new DataGridView();
            //data_table.DataSource=fill_table(this.i_list);
            //data_table.Show();         // showing the data grid view in the form od a table
            //data_table.Visible = true;
            
        }


        /*
         * function to generate all items in a data grid view
         * */

        /*
         void Fill_grid(Item_List l)
        {
            DataGridView data_table = new DataGridView();
            data_table.DataSource = fill_table(l);
             
        }
        */
        
/*
         DataTable fill_table(Item_List l)
         {
            DataTable d = new DataTable();

            Item_Node tmp = l.Item_head.next;
            while (tmp != null)
            {
                string name = tmp.item_name;
                string type = tmp.item_type;
                string attribute = tmp.item_attribute;

                //d.Columns.Add(name,typeof(string));
                
                
                Node inner_tmp = tmp.l_2.head.next;
                while (inner_tmp != tmp.l_2.tail)
                {
                    DataColumn column;

                    column = new DataColumn();
                    //column.DataType = System.Type.GetType("System.string");
                    column.ColumnName = name;

                    d.Columns.Add(column); 
                    if (attribute == null)          // if the attribute is null i.e the user doesn't want to display the attributes
                    {


                        //Create a new row
                        DataRow drow = d.NewRow();

                        switch (type)
                        {
                            case "text":
                                drow[name] = inner_tmp.html_node.InnerText;
                                break;
                            case "Inner Html":
                                drow[name] = inner_tmp.html_node.InnerHtml;
                                break;
                            case "Outer Html":
                                drow[name] = inner_tmp.html_node.OuterHtml;
                                break;
                        }
                        //Add the row to the datatable.
                        d.Rows.Add(drow);

                    }
                    else // when an attribute has to be added 
                    {

                        //Create a new row
                        DataRow drow = d.NewRow();
                        if (inner_tmp.html_node.Attributes[attribute]!=null)
                            drow[name]=inner_tmp.html_node.Attributes[attribute].Value;

                        //Add the row to the datatable.
                        d.Rows.Add(drow);

                    }
                    
                    inner_tmp = inner_tmp.next;
                }


                tmp = tmp.next;
            }
            return d;

        }
*/



         private void button7_Click_1(object sender, EventArgs e)
         {
             i_list.purge_list();// deleting all the items from the list
             // also have to write something so that gridview also becomes emply
             for (int i = this.dataGridView1.Rows.Count - 2; i > -1; i--)
                dataGridView1.Rows.RemoveAt(i);

             id = 1; // setting the value of id so that the next added item's serial number starts from beginning

         }

         private void button8_Click(object sender, EventArgs e)
         {
              DataGridViewSelectedRowCollection r_c= dataGridView1.SelectedRows;
             foreach(DataGridViewRow r in r_c)
             {
                 if (r.Cells[0].Value != null)
                 {
                     int s_no = (int)r.Cells[0].Value;
                     i_list.delete_item_by_id(s_no);
                     dataGridView1.Rows.Remove(r);
                 }
             }
         }


         private void button9_Click(object sender, EventArgs e)
         {
            ListBox.SelectedObjectCollection coll=listBox1.SelectedItems;
            foreach (object o in coll)
            {
                string s=o.ToString();
                HtmlNode meta_value = ag_htmlDoc.DocumentNode.SelectSingleNode("//meta[@name=" + "'"+s+"']");//title[@lang='eng']
                listBox2.Items.Add(s + "::" + meta_value.Attributes["content"].Value);
            }
            //listBox1.Items.Remove(list);
         }

         private void auto_paging_Click(object sender, EventArgs e)
         {
             if (current_item != null)  //check that the user has selected a item before going for auto paging option
             {
                 while ((current_item!=null)&&(current_item.tagName.ToLower() != "a"))  // searching for the anchor element as the next tag
                 {
                     current_item = current_item.parentElement;
                 }
                 string href_value = null;
                 if (current_item != null)
                 {
                     if (current_item.getAttribute("href", 0) != null)
                     {
                         href_value = (string)current_item.getAttribute("href", 0);
                     }
                     if (href_value != null)
                     {
                         paging_form = new form_Paging();
                         paging_form.url = href_value;
                         paging_form.html_doc = ag_htmlDoc;// for the third method and the test Button
                         paging_form.Show();
                         paging_form.VisibleChanged += new System.EventHandler(this.form_Paging_VisibleChanged);
                     }
                     else
                     {
                         paging_form = new form_Paging();
                         paging_form.html_doc = ag_htmlDoc;// for the third method and the test Button
                         paging_form.url = textBox1.Text;
                         paging_form.Show();
                         paging_form.VisibleChanged += new System.EventHandler(this.form_Paging_VisibleChanged);
                     }
                 }
                 else
                 {
                     /* 
                      * i am not sure about the functionality of this
                      * */
                     paging_form = new form_Paging();
                     paging_form.html_doc = ag_htmlDoc;// for the third method and the test Button
                     paging_form.url = textBox1.Text;
                     paging_form.Show();
                     paging_form.VisibleChanged += new System.EventHandler(this.form_Paging_VisibleChanged);
                 }
             }
             else  //case when no item is selected  note: "I don't know whether I need this case or not"
             {
                 paging_form = new form_Paging();
                 paging_form.html_doc = ag_htmlDoc;// for the third method and the test Button
                 paging_form.url = textBox1.Text;
                 paging_form.Show();
                 paging_form.VisibleChanged += new System.EventHandler(this.form_Paging_VisibleChanged);
             }
         }
         public void form_Paging_VisibleChanged(object sender, EventArgs e)
         {
             if (paging_form.radioButton1.Checked)
             {
                 add_auto_paging.Visible = true;  //make the button for adding the node for auto_paging visible
             }
             if (paging_form.radioButton2.Checked)
             {
                 int i3 = 0;
                 //calculate the path again
                 String[] temp_s = new string[50];
                 int[] temp_i = new int[50];
                 IHTMLElement temp = current_item;
                 while (!(temp.tagName.ToLower().Equals("html"))) // I donot know why the loop is running indefinitely when we are using null condition.
                 {
                     int i2 = cal_relative_index(temp, temp.tagName);
                     temp_s[i3] = temp.tagName;
                     temp_i[i3] = i2 + 1;  // to take care that in xpath the indices start from 1 as opposer to here where it starts from 0
                     i3++;
                     temp = temp.parentElement;
                 }

                 page p = search_for_auto_paging_node(temp_s, temp_i, i3, current_item);
                 if (p != null)
                 {
                     auto_page = new Auto_Paging_Class();
                     auto_page.method = 2;          //setting the method 2 for single variable
                     auto_page.node = p.n1;         //setting the node
                     
                     auto_page.page_no_url = paging_form.textBox1.Text;  //setting the Url on which regular expression to be applied

                     auto_page.starting_page_no=Convert.ToInt16(paging_form.textBox3.Text);
                     auto_page.ending_page_no = Convert.ToInt16(paging_form.textBox4.Text);

                     auto_page.variable_name = paging_form.textBox2.Text;  //setting the name of the variable
                     
                     // may be i Don't need this in method 2
                     auto_page.path = p.s1;
                     auto_page.base_url = base_url; //setting the base_url
                     //auto_page.starting_url = textBox1.Text;  // setting the starting url of the webpage for auto paging
                 }
                 else
                 {
                     auto_page = null;  // this means that the node representing the next page was not found. have to handle it some where
                 }
             }

             if (paging_form.radioButton3.Checked)  //case when the text on the next button is used
             {
                 //ag_htmlDoc.DocumentNode.SelectNodes("")
                 auto_page = new Auto_Paging_Class();
                 auto_page.next_link_text = paging_form.textBox5.Text;
                 auto_page.method = 3;
                 auto_page.method3_url=textBox1.Text;
                 auto_page.base_url = base_url; //setting the base_url

                 auto_page.next_link_tag_name = paging_form.next_tag_node_name; //setting the name of the tag to search easily

             }

         }



         private void add_auto_paging_Click(object sender, EventArgs e)
         {
             if (current_item != null)
             {
                 int i3 = 0; 
                 auto_page = new Auto_Paging_Class();
                 while (current_item.tagName.ToLower() != "a")  // searching for the anchor element as the next tag
                 {
                     current_item = current_item.parentElement;
                 }
                 //calculate the path again
                 String[] temp_s=new string[50];
                 int[] temp_i=new int[50];
                 IHTMLElement temp = current_item;
                 while (!(temp.tagName.ToLower().Equals("html"))) // I donot know why the loop is running indefinitely when we are using null condition.
                 {
                     int i2 = cal_relative_index(temp, temp.tagName);
                     temp_s[i3] = temp.tagName;
                     temp_i[i3] = i2 + 1;  // to take care that in xpath the indices start from 1 as opposer to here where it starts from 0
                     i3++; 
                     temp = temp.parentElement;
                 }



                 page p=search_for_auto_paging_node(temp_s,temp_i,i3,current_item);
                 if (p != null)
                 {
                     auto_page.method = 1;  //setting the first method
                     auto_page.node = p.n1;
                     auto_page.path = p.s1;
                     auto_page.base_url = base_url; //setting the base_url
                     auto_page.starting_url = textBox1.Text;  // setting the starting url of the webpage for auto paging
                 }
                 else
                 {
                     auto_page = null;  // this means that the node representing the next page was not found. have to handle it some where
                 }
             }
             else
             {
                 MessageBox.Show("please select an item from the webpage first");
             }
         }

         /*
  * function to compute the relative Xpath Query that is able to select a single element*/
         private page search_for_auto_paging_node(string[] S, int[] A, int size,IHTMLElement e)  //CHANGE
         {
             page p1=null;  // an object of a class to return two values from the function

             int pos = size - 1;
             int i = 0;
             int count = -1;
             while ((count != 1) && (pos != 0))
             {
                 string path = @"//";    // starting with the body tag  donot need a html tag
                 for (i = pos; i >= 0; i--)
                 {
                     if ((!(S[i].ToLower().Equals("tbody"))))        // ignoring the tbody tag
                     {
                         if (i == 0)
                         {
                             path = path + S[i].ToLower() + "[" + A[i].ToString() + "]";
                         }
                         else
                         {
                             path = path + S[i].ToLower() + "[" + A[i].ToString() + @"]/";
                         }
                     }
                 }
                 HtmlNodeCollection l1 = ag_htmlDoc.DocumentNode.SelectNodes(path);
                 if (l1 != null)
                 {
                     if (l1.Count == 1)
                     {
                         foreach (HtmlNode n in l1)
                         {
                             p1 = new page();
                                 p1.n1 = n;
                                 p1.s1 = path;
                                 return p1;
                         }
                     }
                     else
                     {
                         foreach (HtmlNode n in l1)
                         {
                             if ((n.Attributes["href"] == e.getAttribute("href", 0))&&(n.Name==e.tagName))  //If the href is same and the tagnames are also same
                             {
                                 p1 = new page();
                                 p1.n1 = n;
                                 p1.s1 = path;
                                 return p1;
                             }
                         }
                     }
                 }
                 pos--;
             }
             return null;
         }

         private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
         {

         }



    }
}


    
   
 