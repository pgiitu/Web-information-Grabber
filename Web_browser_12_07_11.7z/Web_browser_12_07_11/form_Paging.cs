﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Windows.Controls;
using mshtml;
using System.Xml;
using System.IO;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Net;

namespace Web_Browser
{
    public partial class form_Paging : Form
    {
        public string url;
        public HtmlAgilityPack.HtmlDocument html_doc;
        public string next_tag_node_name;
        public form_Paging()
        {
            InitializeComponent();
            url = null;
            next_tag_node_name = null;
            this.button3.Click += new System.EventHandler(this.button3_Click);
        }
        public form_Paging(string url)
        {
            InitializeComponent();
            this.textBox1.Text = url;
            next_tag_node_name = null;
        }

        /*
        public form_Paging(HtmlAgilityPack.HtmlDocument doc1)
        {
            InitializeComponent();
            
        }
        */
        



        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                this.Visible=false;
            }
            if (radioButton2.Checked)
            {
                if (this.textBox2.Text == "")
                {
                    MessageBox.Show("PLEASE ENTER THE NAME OF THE VARIBALE FOR AUTO PAGING");
                }
                else
                {
                    if ((this.textBox3.Text == "")||(this.textBox4.Text==""))
                    {
                        MessageBox.Show("please Enter valid page number");
                    }
                    else
                    {
               
                        // check if the varibale is present in the URL or Not
                        string regex = textBox2.Text + "=\\d*";
                        if (System.Text.RegularExpressions.Regex.IsMatch(textBox1.Text, regex))
                        {
                            MessageBox.Show("found the variable");
                            this.Visible = false;
                        }
                        else
                        {
                            MessageBox.Show("the variable entered by you is not present in URL. Please enter a valid variable");
                        }
                    }
                }

            }
            if (radioButton3.Checked)
            {
                if (textBox5.Text == null)
                {
                    MessageBox.Show("please entyer the name of the next button first");
                }
                else
                {
                    // have to write code for the third method
                    this.Visible = false;
                }
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                this.textBox1.Text = this.url;
                this.textBox2.Enabled = true;
                this.textBox3.Enabled = true;
                this.textBox4.Enabled = true;
            }
            else
            {
                this.textBox1.Enabled = false;
                this.textBox2.Enabled = false;
                this.textBox3.Enabled = false;
                this.textBox4.Enabled = false;
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool flag=false;
            HtmlAgilityPack.HtmlNodeCollection c= this.html_doc.DocumentNode.SelectNodes("//*");
            foreach (HtmlNode n in c)
            {
                if (!flag)
                {
                    if (n.InnerText.Contains(this.textBox5.Text)||(System.Text.RegularExpressions.Regex.Replace(n.InnerText,"&\\w*;","").Contains(this.textBox5.Text))) //comparing the innerHtml to find the next tag
                    {
                        if (n.Attributes["href"]!= null)
                        {
                            string s = n.Attributes["href"].Value;
                            flag = true;
                            this.next_tag_node_name = n.Name;
                            MessageBox.Show("i have got the tag required");
                            
                            break;
                        }

                    }
                }
                    /*
                else
                {
                    if(n.InnerText.Equals(this.textBox5.Text))
                    {
                        if (n.ChildNodes == null)
                        {
                            if (n.Attributes["href"].Value != null)
                            {
                                flag=true;
                                MessageBox.Show("i have got the tag required");
                            }
                        }
                        else
                        {
                            while(n.ChildNodes)
                        }
                    }
                }
                     * */
            }
            if (!flag)
            {
                MessageBox.Show("Could not find the Next page");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                textBox5.Enabled = true;
                button3.Enabled = true;
            }
            else
            {
                textBox5.Enabled = false;
                button3.Enabled = false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }





    }
}
