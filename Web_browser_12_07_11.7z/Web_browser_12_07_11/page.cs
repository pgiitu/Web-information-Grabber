﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Windows.Controls;
using mshtml;
using System.Xml;
using System.IO;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Net;
namespace Web_Browser
{
        public class page       // a class to uded to return two values from a function
        {
            public string s1;
            public HtmlNode n1;
            

            public page()
            {
                    s1 = null;
                    n1=null;
            }
        }


}
